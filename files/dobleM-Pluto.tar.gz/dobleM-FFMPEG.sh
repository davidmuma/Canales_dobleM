#!/bin/bash
/usr/bin/ffmpeg -i \$1 -c copy -f mpegts pipe:1